function logOut(){
    sessionStorage.clear();
    window.open("../index.html","_self")
}